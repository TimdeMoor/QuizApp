﻿using System;
using System.Collections.Generic;
using System.Configuration;
using QuizLib.Data;
using QuizLib.Interface;
using QuizLib.Logic;

namespace ConsoleTestApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Test");
            Console.ReadLine();
        }
    }
}
