namespace Quizapp
{
    partial class SubCategorie
    {
    }
}