﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ASPQuizApp.Models
{
    public class GebruikerLijstViewModel
    {
        public List<GebruikerDetailsViewModel> GebruikerDetailsLijst = new List<GebruikerDetailsViewModel>();
    }
}
