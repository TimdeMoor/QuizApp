﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using QuizLib.Logic;

namespace ASPQuizApp.Models
{
    public class AddSubCategorieViewModel
    {
        public List<SubCategorie> SubCategories { get; set; }
    }
}
