﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ASPQuizApp.Models
{
    public class SubCategorieLijstViewModel
    {
        public List<SubCategorieDetailsViewModel> SubCategorieLijst = new List<SubCategorieDetailsViewModel>();
    }
}
